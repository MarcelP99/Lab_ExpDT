//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: B1DetectorConstruction.cc 75117 2013-10-28 09:38:37Z gcosmo $
//
/// \file DetectorConstruction.cc
/// \brief Implementation of the DetectorConstruction class

#include "DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Element.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4Isotope.hh"
#include "G4SubtractionSolid.hh"
#include "G4VisAttributes.hh"

//inlcudes for the sensitive detector
#include "G4SDParticleFilter.hh"
#include "G4VPrimitiveScorer.hh"
#include "G4PSEnergyDeposit.hh"
#include "G4MultiFunctionalDetector.hh"
#include "G4SDManager.hh"
#include "G4LogicalVolumeStore.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::DetectorConstruction()
: G4VUserDetectorConstruction()
{ }

//Destructor
DetectorConstruction::~DetectorConstruction()
{ }



//Define the detector
G4VPhysicalVolume* DetectorConstruction::Construct()
{  

  //============= MATERIAL DEFINITION =================
  G4NistManager* nist = G4NistManager::Instance();  // Get nist material manager
  //G4Material* galactic = nist->FindOrBuildMaterial("G4_Galactic"); //Build vacuum material using the nist manager
  //G4Material* BGO = nist->FindOrBuildMaterial("G4_BGO"); //Build vacuum material using the nist manager
  G4Material* air = nist->FindOrBuildMaterial("G4_AIR"); //Build vacuum material using the nist manager
  //G4Material* fAlu = nist->FindOrBuildMaterial("G4_Al"); //Build vacuum material using the nist manager
  G4Material* lead = nist->FindOrBuildMaterial("G4_Pb"); //Build lead material using the nist manager
  G4Material* Aluminium = nist->FindOrBuildMaterial("G4_Al"); //Build aluminium material using the nist manager
  G4Material* Sodium_iodide = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE"); //Build Sodium_iodide material using the nist manager
  G4Material* Plastic = nist->FindOrBuildMaterial("G4_PLASTIC_SC_VINYLTOLUENE"); // Build Plastic material using nist manager


  // LaBr-crystal material
  G4Element *Ce = nist->FindOrBuildElement("Ce");
  G4Element *La = nist->FindOrBuildElement("La");
  G4Element *Br = nist->FindOrBuildElement("Br");
  G4Material* fLaBr = new G4Material("LaBr:Ce",5.08*g/cm3,3,kStateSolid);
  fLaBr->AddElement(Ce,1.25*perCent);
  fLaBr->AddElement(La,23.75*perCent);
  fLaBr->AddElement(Br,75.0*perCent);

  // Ge-crystal material
  //G4Material *fGe = new G4Material("HPGe",32.,72.640*g/mole,5.323*g/cm3,kStateSolid);

  //============= GEOMETRY DESCRIPTION =================

  // Option to switch on/off checking of volumes overlaps
  G4bool checkOverlaps = true;
  
  
  //========== World ==================================
  G4double world_sizeXY = 50.*cm;
  G4double world_sizeZ  = 50.*cm;

  G4Box* solidWorld =
    new G4Box("WorldSolid",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size


  G4LogicalVolume* WorldLV =
    new G4LogicalVolume(solidWorld,          //its solid
                        air,           //its material
                        "WorldLV");            //its name

  G4VPhysicalVolume* WorldPV =
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,0),       //at (0,0,0)
                      WorldLV,            //its logical volume
                      "WorldPV",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  // Force the detector to be drawn with wireframe
  G4VisAttributes *WorldVisAtt = new G4VisAttributes();
  WorldVisAtt->SetForceWireframe(true);
  WorldLV->SetVisAttributes(WorldVisAtt);

  // ========== Lead box sourounding =======

  G4double lead_cube_width = 162.0*mm; // width of detector = width of cube inside plus 40mm on each side
  G4double lead_cube_depth = 179.5*mm; //depth of detector = depth of cube inside plus 40mm on each side
  G4double radius_hole_lead = 0.5*52*mm; //radius of detctor hole
  G4double depth_hole_lead = 40.0*mm; //depth of hole, completly through

  // lead

  //G4Tubs* solidDetector = new G4Tubs("DetectorSolid",0.,detector_radius,0.5*detector_length,0.,360.*deg);

  G4Box* lead_complete_box = new G4Box("SuroundingLeadBox", 0.5*lead_cube_width, 0.5*lead_cube_depth, 0.5*lead_cube_width); //create lead cube

  G4Tubs* hole_lead_top = new G4Tubs("Top_lead_hole",0.,radius_hole_lead,0.5*depth_hole_lead+0.5* 5*mm,0., 360.*deg); //detector hole
  
  G4SubtractionSolid* leadSurounding = new G4SubtractionSolid("SuroundingLead",lead_complete_box, hole_lead_top,0,G4ThreeVector(0.,0.,58.5*mm));//cut detector hole in it


  G4LogicalVolume* LeadSuroundingLV = 
    new G4LogicalVolume(leadSurounding,          //its solid
                        //fLaBr,           //its material
                        lead,           //its material
                        "LeadSuroundingLV");            //its name


  /*G4VPhysicalVolume* DetectorPV =*/
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,0),  //at (0,0,0)
                      LeadSuroundingLV,            //its logical volume
                      "LeadSuroundingPV",          //its name
                      WorldLV,               //its mother volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  G4VisAttributes *GeVisAtt = new G4VisAttributes(G4Color::Red());
  GeVisAtt->SetForceWireframe(true);
  LeadSuroundingLV->SetVisAttributes(GeVisAtt);
  //====================================================



    // ========== Cube of plastic inside  =======


  G4double plastic_cube_width = 82.0*mm; // width of hole 
  G4double plastic_cube_depth = 99.5*mm; //depth of hole

  G4Tubs* plastic_box_hole = new G4Tubs("plastic_box_hole",0.,radius_hole_lead,0.5*5*mm,0., 360.*deg); //plate hole

  G4Box* PlasticBox_help = new G4Box("PlasticBox_help", 0.5*plastic_cube_width, 0.5*plastic_cube_depth, 0.5*plastic_cube_width);

  G4SubtractionSolid* PlasticBox = new G4SubtractionSolid("PlasticBox",PlasticBox_help, plastic_box_hole,0,G4ThreeVector(0.,0.,38.5*mm));//cut hole in it

  G4LogicalVolume* PlasticBoxLV = 
    new G4LogicalVolume(PlasticBox,          //its solid
                        //fLaBr,           //its material
                        Plastic,           //its material
                        "PlasticBoxLV");            //its name


  /*G4VPhysicalVolume* DetectorPV =*/
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,0),  //at (0,0,0)
                      PlasticBoxLV,            //its logical volume
                      "PlasticBoxPV",          //its name
                      LeadSuroundingLV,               //its mother volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  G4VisAttributes *GeVisAttPlasticCube = new G4VisAttributes(G4Color::White());
  GeVisAttPlasticCube->SetForceWireframe(true);
  PlasticBoxLV->SetVisAttributes(GeVisAttPlasticCube);
  //====================================================


    // ========== Cube representing the hole inside  =======


  G4double lead_cube_hole_width = 72.0*mm; // width of hole 
  G4double lead_cube_hole_depth = 89.5*mm; //depth of hole

  // air

  G4Box* leadSuroundingHole = new G4Box("HoleSuroundingLead", 0.5*lead_cube_hole_width, 0.5*lead_cube_hole_depth, 0.5*lead_cube_hole_width);

  G4LogicalVolume* leadSuroundingHoleLV = 
    new G4LogicalVolume(leadSuroundingHole,          //its solid
                        //fLaBr,           //its material
                        air,           //its material
                        "leadSuroundingHoleLV");            //its name


  /*G4VPhysicalVolume* DetectorPV =*/
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,0),  //at (0,0,0)
                      leadSuroundingHoleLV,            //its logical volume
                      "leadSuroundingHolePV",          //its name
                      PlasticBoxLV,               //its mother volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  G4VisAttributes *GeVisAttHoleLeadCube = new G4VisAttributes(G4Color::White());
  GeVisAttHoleLeadCube->SetForceWireframe(true);
  leadSuroundingHoleLV->SetVisAttributes(GeVisAttHoleLeadCube);
  //====================================================

  // ========== Plastic plate 1  source =======


  G4double plastuc_plate_width = 72.0*mm; // width of lead plate 
  G4double plastic_plate_depth = 89.5*mm; //depth of lead plate
  G4double plastic_plate_thickness = 5*mm; //thickness, needs to be varied

  // air

  G4Box* plastic_plate_1 = new G4Box("plastic_plate_1", 0.5*plastuc_plate_width, 0.5*plastic_plate_depth, 0.5*plastic_plate_thickness);

  G4LogicalVolume* plastic_plate_1LV = 
    new G4LogicalVolume(plastic_plate_1, Plastic,  "plastic_plate_1LV");



    new G4PVPlacement(0,G4ThreeVector(0,0,-27.5*mm), plastic_plate_1LV, "plastic_plate_1PV", leadSuroundingHoleLV, false, 0, checkOverlaps);

  G4VisAttributes *GeVisAttplastic_plate_1 = new G4VisAttributes(G4Color::White());
  plastic_plate_1LV->SetVisAttributes(GeVisAttplastic_plate_1);
  //====================================================

    // ========== Plastic plate 2 lead  =======

  // air

  G4double plastic_plate_radius = 23*mm; //just a guess

  G4Tubs* plastic_plate_hole = new G4Tubs("plastic_plate_hole",0.,plastic_plate_radius,0.5*plastic_plate_thickness+0.01*mm,0., 360.*deg); //plate hole

  G4Box* plastic_plate_2_box = new G4Box("plastic_plate_2_box", 0.5*plastuc_plate_width, 0.5*plastic_plate_depth, 0.5*plastic_plate_thickness);

  G4SubtractionSolid* plastic_plate_2 = new G4SubtractionSolid("plastic_plate_2",plastic_plate_2_box, plastic_plate_hole,0,G4ThreeVector(0.,0.,0.));//cut hole in it



  G4LogicalVolume* plastic_plate_2LV = 
    new G4LogicalVolume(plastic_plate_2, Plastic,  "plastic_plate_2LV");



    new G4PVPlacement(0,G4ThreeVector(0,0,-9.5*mm), plastic_plate_2LV, "plastic_plate_2PV", leadSuroundingHoleLV, false, 0, checkOverlaps);

  G4VisAttributes *GeVisAttplastic_plate_2 = new G4VisAttributes(G4Color::White());
  plastic_plate_2LV->SetVisAttributes(GeVisAttplastic_plate_2);
  //====================================================




    // ========== Lead plate inbetween  =======


  G4double lead_plate_width = 60.0*mm; // width of lead plate 
  G4double lead_plate_depth = 71.5*mm; //depth of lead plate
  G4double lead_plate_thickness = 1.5*mm; //thickness, needs to be varied

  // air

  G4Box* lead_plate = new G4Box("PlateLead", 0.5*lead_plate_width, 0.5*lead_plate_depth, 0.5*lead_plate_thickness);

  G4LogicalVolume* lead_plateLV = 
    new G4LogicalVolume(lead_plate, lead,  "lead_plateLV");


 
    new G4PVPlacement(0,G4ThreeVector(0,-1*mm,-7*mm + 0.5*lead_plate_thickness), lead_plateLV, "lead_platePV", leadSuroundingHoleLV, false, 0, checkOverlaps);

  G4VisAttributes *GeVisAttLeadPlate = new G4VisAttributes(G4Color::Grey());
  lead_plateLV->SetVisAttributes(GeVisAttLeadPlate);
  //====================================================


    // ========== Detector Aluminium sourounding  =======


  G4double diameter_aluminium_detector = 52.*mm; // diameter of aluminium 
  G4double depth_aluminium_detector = 51.*mm; // depth of aluminium

  // air

  G4Tubs* detectorAluminium = new G4Tubs("Aluminium_detector",0.,0.5*diameter_aluminium_detector,0.5*depth_aluminium_detector,0., 360.*deg); //detector hole

  G4LogicalVolume* detectorAluminiumLV = 
    new G4LogicalVolume(detectorAluminium,          //its solid
                        //fLaBr,           //its material
                        Aluminium,           //its material
                        "detectorAluminiumLV");            //its name


  /*G4VPhysicalVolume* DetectorPV =*/
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,61.5*mm),  //at (0,0,0)
                      detectorAluminiumLV,            //its logical volume
                      "detectorAluminiumPV",          //its name
                      WorldLV,               //its mother volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  G4VisAttributes *GeVisAttDetectorAlu = new G4VisAttributes(G4Color::White());
  detectorAluminiumLV->SetVisAttributes(GeVisAttDetectorAlu);
  //====================================================




    // ========== Detector=======


  G4double diameter_detector = 51.*mm; // diameter of detector 
  G4double depth_detector = 51.*mm; // depth of detector

  // air

  G4Tubs* detector = new G4Tubs("Detector",0.,0.5*diameter_detector,0.5*depth_detector,0., 360.*deg); //detector hole

  G4LogicalVolume* detectorLV = 
    new G4LogicalVolume(detector,          //its solid
                        //fLaBr,           //its material
                        Sodium_iodide,           //its material
                        "detectorLV");            //its name


  /*G4VPhysicalVolume* DetectorPV =*/
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(0,0,0),  //at (0,0,0)
                      detectorLV,            //its logical volume
                      "detectorPV",          //its name
                      detectorAluminiumLV,               //its mother volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  G4VisAttributes *GeVisAttDetector = new G4VisAttributes(G4Color::Cyan());
  detectorLV->SetVisAttributes(GeVisAttDetector);
  //====================================================




  SetupDetectors();
  return WorldPV; //must return G4VPhysicalVolume pointer to the world


}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void DetectorConstruction::SetupDetectors()
{
  // we now create a primitive scorer which registers energy deposits
  G4VPrimitiveScorer *scorer = new G4PSEnergyDeposit("eDep",0);

  // Create a filter: we want to register energy deposits from electrons and positrons to model a typical gamma-ray detector
  // We also need to add gammas to our filter: This is because of the way geant4 treats "cuts". If the range of the
  // electron/positron is smaller than the specified range cut ti will not be created and the energy will be counted as
  // having been deposit by the gamma-ray.
  G4String filterName, particleName;
  G4SDParticleFilter* aFilter = new G4SDParticleFilter(filterName="epFilter");
  aFilter->add(particleName="e-");
  aFilter->add(particleName="e+");
  aFilter->add(particleName="gamma");

  // we assign our recently created filter to it
  scorer->SetFilter(aFilter);

  // now we assign the primitive scorrer to a detector, one could add more types of primitive scorers to this same detector
  G4MultiFunctionalDetector* det = new G4MultiFunctionalDetector("theDetector");
  det->RegisterPrimitive(scorer);

  // we then assign the sensitivity to a logicla volume
  G4LogicalVolume *logicVolume = G4LogicalVolumeStore::GetInstance()->GetVolume("detectorLV"); //retrieve it by its name
  logicVolume->SetSensitiveDetector(det);

  // finaly we register the created detector to the detector manager 
  G4SDManager::GetSDMpointer()->AddNewDetector(det);
}